# GrantGlide – Scholarship Matcher

A lightweight scholarship discovery dashboard with a profile-based eligibility matcher, deadline countdowns, document readiness checklist, and application pipeline.

## Requirements
- Node.js 18 or newer
- npm (included with Node.js)

## Run on Windows (Command Prompt)
1. Extract `GrantGlide_90_Percent.zip` to a folder.
2. Open **Command Prompt** and move into the extracted project folder, for example:
   ```bat
   cd %USERPROFILE%\Downloads\grantglide
   ```
3. Install dependencies (first run only):
   ```bat
   npm install
   ```
4. Start the website:
   ```bat
   npm start
   ```
5. Open **http://localhost:3000** in your browser. Keep the Command Prompt window open while using the app.

To stop the server, press `Ctrl+C` in Command Prompt.

## Run tests
Open a second Command Prompt in the project folder and run:
```bat
npm test
```

## Features
- Student profile form with input validation.
- Rule-based eligibility matching. A scholarship's `rules` array is OR; conditions inside each rule are AND.
- Scholarship cards, category filters, match score, and deadline countdown.
- Scholarship details, official portal link, and per-scheme document checklist.
- Document expiry alerts and application stages (Bookmarked, Applied, Under Review, Awarded).
- Profile, document, and tracker data saved locally in `data/store.json`.
- Health endpoint at `/api/health`.

## Project structure
- `matcher.js` – eligibility rule engine.
- `server.js` – Express API and local persistence.
- `data/scholarships.json` – sample scholarship catalogue.
- `public/` – frontend files.
- `test.js` – matcher regression tests.

## Important accuracy note
Scholarship amounts, deadlines, income limits, and eligibility details in the included catalogue are sample/approximate data and may be outdated. Always confirm current requirements on the linked official portal before applying. This project is a student prototype, not an official government service.
