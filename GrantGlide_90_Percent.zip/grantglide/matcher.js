// GrantGlide rule engine.
// Each item in `rules` is an OR alternative; conditions inside it are ANDed.
const ARRAY_FIELDS = ['castes', 'genders', 'states', 'degrees'];

function checkRule(rule = {}, profile = {}) {
  const fails = [];
  let checked = 0;
  const test = (key, predicate, label) => {
    if (rule[key] === undefined) return;
    checked += 1;
    if (!predicate) fails.push(label);
  };

  test('castes', Array.isArray(rule.castes) && rule.castes.includes(profile.caste), 'caste category');
  test('maxIncome', Number.isFinite(profile.income) && profile.income <= rule.maxIncome, 'family income');
  test('minIncome', Number.isFinite(profile.income) && profile.income >= rule.minIncome, 'family income');
  test('minGpa', Number.isFinite(profile.gpa) && profile.gpa >= rule.minGpa, 'GPA');
  test('maxGpa', Number.isFinite(profile.gpa) && profile.gpa <= rule.maxGpa, 'GPA');
  test('genders', Array.isArray(rule.genders) && rule.genders.includes(profile.gender), 'gender');
  test('states', Array.isArray(rule.states) && rule.states.includes(profile.state), 'domicile state');
  test('degrees', Array.isArray(rule.degrees) && rule.degrees.includes(profile.degree), 'degree');
  return { fails, checked };
}

function evaluate(scholarship, profile) {
  const alternatives = Array.isArray(scholarship.rules) && scholarship.rules.length
    ? scholarship.rules : [{}];
  const evaluations = alternatives.map(rule => checkRule(rule, profile));
  // A scheme is eligible if any OR alternative passes. Otherwise show the
  // closest alternative's unmet requirements for useful diagnostics.
  const best = evaluations.reduce((a, b) =>
    b.fails.length < a.fails.length || (b.fails.length === a.fails.length && b.checked > a.checked) ? b : a
  );
  const eligible = best.fails.length === 0;
  const score = eligible ? Math.min(100, 55 + best.checked * 9) : 0;
  return { eligible, score, fails: best.fails, checked: best.checked };
}

function matchAll(list, profile) {
  return list
    .map(s => ({ ...s, match: evaluate(s, profile) }))
    .filter(s => s.match.eligible)
    .sort((a, b) => b.match.score - a.match.score || new Date(a.deadline) - new Date(b.deadline));
}

module.exports = { checkRule, evaluate, matchAll };
