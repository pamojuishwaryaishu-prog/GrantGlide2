@echo off
cd /d "%~dp0"
echo Installing project dependencies (first run may take a minute)...
call npm install
if errorlevel 1 (
  echo Dependency installation failed. Check your internet connection and Node.js installation.
  pause
  exit /b 1
)
echo Starting GrantGlide at http://localhost:3000
start "GrantGlide" http://localhost:3000
call npm start
pause
