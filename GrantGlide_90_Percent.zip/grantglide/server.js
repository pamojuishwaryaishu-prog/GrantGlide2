const express = require('express');
const fs = require('fs');
const path = require('path');
const { matchAll } = require('./matcher');

const app = express();
const DATA_DIR = path.join(__dirname, 'data');
const STORE = path.join(DATA_DIR, 'store.json');
const scholarships = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'scholarships.json'), 'utf8'));
const PORT = Number(process.env.PORT) || 3000;

app.disable('x-powered-by');
app.use(express.json({ limit: '32kb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});

const daysFromNow = n => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10);
function defaultState() {
  return {
    profile: null,
    tracker: {},
    docs: {
      income: { ready: true, expiry: daysFromNow(20) },
      marks: { ready: true, expiry: '' },
      aadhaar: { ready: true, expiry: '' }
    }
  };
}
function readState() {
  try {
    const saved = JSON.parse(fs.readFileSync(STORE, 'utf8'));
    return { ...defaultState(), ...saved, docs: { ...defaultState().docs, ...(saved.docs || {}) }, tracker: saved.tracker || {} };
  } catch (err) {
    if (err.code !== 'ENOENT') console.error('Could not read saved state:', err.message);
    return defaultState();
  }
}
function writeState(state) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const temp = `${STORE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(state, null, 2));
  fs.renameSync(temp, STORE);
}
function validateProfile(body) {
  const p = { ...body, income: Number(body.income), gpa: Number(body.gpa) };
  const valid = p.caste && p.state && p.gender && p.degree &&
    Number.isFinite(p.income) && p.income >= 0 &&
    Number.isFinite(p.gpa) && p.gpa >= 0 && p.gpa <= 10;
  return valid ? p : null;
}

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'GrantGlide', scholarships: scholarships.length }));
app.get('/api/scholarships', (req, res) => res.json(scholarships));
app.get('/api/scholarships/:id', (req, res) => {
  const item = scholarships.find(s => s.id === req.params.id);
  return item ? res.json(item) : res.status(404).json({ error: 'Scholarship not found.' });
});
app.post('/api/match', (req, res) => {
  const profile = validateProfile(req.body || {});
  if (!profile) return res.status(400).json({ error: 'Enter all profile fields. Income must be 0 or more and GPA must be between 0 and 10.' });
  const state = readState();
  state.profile = profile;
  writeState(state);
  return res.json({ total: scholarships.length, results: matchAll(scholarships, profile) });
});
app.get('/api/state', (req, res) => res.json(readState()));
app.put('/api/state', (req, res) => {
  const body = req.body || {};
  if (body.docs !== undefined && (typeof body.docs !== 'object' || body.docs === null || Array.isArray(body.docs)))
    return res.status(400).json({ error: 'Documents must be an object.' });
  if (body.tracker !== undefined && (typeof body.tracker !== 'object' || body.tracker === null || Array.isArray(body.tracker)))
    return res.status(400).json({ error: 'Application tracker must be an object.' });
  const state = readState();
  if (body.docs) state.docs = { ...state.docs, ...body.docs };
  if (body.tracker) state.tracker = body.tracker;
  writeState(state);
  return res.json({ ok: true });
});

app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  return res.status(err instanceof SyntaxError ? 400 : 500).json({ error: err instanceof SyntaxError ? 'Invalid JSON request.' : 'Something went wrong. Please try again.' });
});

app.listen(PORT, () => console.log(`GrantGlide running at http://localhost:${PORT}`));
