const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { evaluate, matchAll } = require('./matcher');
const list = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'scholarships.json'), 'utf8'));

const cases = [
  { name: 'Telangana BC student, engineering', p: { caste: 'BC', income: 150000, state: 'Telangana', gender: 'Female', degree: 'Engineering', gpa: 8.5 }, mustHave: ['pragati', 'ts-bc', 'post-matric-obc'], mustNot: ['ts-scst', 'top-class-sc'] },
  { name: 'SC student, Telangana', p: { caste: 'SC', income: 180000, state: 'Telangana', gender: 'Male', degree: 'Engineering', gpa: 6.2 }, mustHave: ['post-matric-sc', 'ts-scst', 'top-class-sc'], mustNot: ['pragati'] },
  { name: 'General student, high income', p: { caste: 'General', income: 3000000, state: 'Telangana', gender: 'Male', degree: 'Arts', gpa: 9 }, mustHave: [], mustNot: ['post-matric-sc', 'csss'] }
];
let failures = 0;
for (const c of cases) {
  const ids = matchAll(list, c.p).map(s => s.id);
  const errors = [...c.mustHave.filter(id => !ids.includes(id)), ...c.mustNot.filter(id => ids.includes(id))];
  console.log(errors.length ? 'FAIL' : 'PASS', c.name, `(${ids.length} matches)`);
  errors.forEach(e => console.error('  Unexpected result:', e));
  failures += errors.length;
}

const orScholarship = { rules: [{ castes: ['SC'], maxIncome: 100000 }, { castes: ['BC'], maxIncome: 200000 }] };
assert.strictEqual(evaluate(orScholarship, { caste: 'BC', income: 150000 }).eligible, true, 'OR alternatives should be supported');
assert.strictEqual(evaluate({ rules: [{ minGpa: 7 }] }, { gpa: 6 }).eligible, false, 'GPA minimum should be enforced');
assert.strictEqual(evaluate({ rules: [{ maxGpa: 8 }] }, { gpa: 9 }).eligible, false, 'GPA maximum should be enforced');
assert.strictEqual(evaluate({ rules: [{ minIncome: 100000 }] }, { income: 90000 }).eligible, false, 'Minimum income should be enforced');
console.log('PASS rule-engine edge cases');
if (failures) process.exit(1);
